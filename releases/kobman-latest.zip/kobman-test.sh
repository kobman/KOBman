#!/bin/bash


cd ${KOBMAN_DIR}/tmp
sudo wget https://github.com/EtricKombat/KOBman/blob/master/releases/kobman-test.zip
unzip kobman-test.zip
  
 

