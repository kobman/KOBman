
function __kob_update{

__kobman_echo_yellow "Testing update command"


}
