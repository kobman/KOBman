#!/bin/bash

function __kob_update {

__kobman_echo_red "Testing update command"


}
