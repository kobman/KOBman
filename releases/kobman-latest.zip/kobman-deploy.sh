
function __kob_deploy{


__kobman_echo_red "Testing deploy command"
__kobman_echo_red "test-2"

}
