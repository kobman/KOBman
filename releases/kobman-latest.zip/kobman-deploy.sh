
function __kob_deploy{

__kobman_echo_yellow "Testing deploy command"


}
