
function __kob_deploy{

__kobman_echo_red "Testing deploy command"


}
