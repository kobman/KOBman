#!/usr/bin/env bash


function __kob_version {

                                                                   
sudo figlet KOB - Version -f small


#	__kobman_echo_yellow ${KOBMAN_VERSION_0.01}
}
