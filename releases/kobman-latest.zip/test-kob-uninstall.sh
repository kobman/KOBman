#!/bin/bash

sudo figlet Testing
sudo figlet uninstall
sudo figlet command



