#!/bin/bash
sudo figlet Testing
sudo figlet kobvon
