#!/bin/bash

sudo figlet Testing
sudo figlet list
sudo figlet command


