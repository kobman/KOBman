#!/bin/bash


sudo figlet Testing
sudo figlet install
sudo figlet command

