#!/bin/bash

sudo figlet Testing
sudo figlet help
sudo figlet command


