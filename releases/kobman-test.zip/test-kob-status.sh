#!/bin/bash


sudo figlet Testing
sudo figlet status


sudo figlet command
