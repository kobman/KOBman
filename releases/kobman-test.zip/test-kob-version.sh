#!/bin/bash


sudo figlet Testing
sudo figlet version


sudo figlet command

